﻿Ofentse Terence Sithole
Automated Leave Requests Documentation

Step 1: Microsoft Forms
https://forms.office.com/r/AXeuMbpp4p?origin=lprLink

Step 2: Sharepoint

Creation for the website has been done successfully using the sharepoint and the website name is Automated Leave Requested, and the Site taken was Team Site. I have added my team members.



Within the team site and I have created the blank list and which is named Leave Requests along with the Description which says “Track Employee Leave Submissions”
![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.001.png)
Added the columns which they are 7 columns  and with that being added it gives clarity on which column is where and more exposure will be given to the user on which day they took leave and when they are coming back to work as well having their information such as full name and email address.
![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.002.png)

Step 3: PowerAutomate
I have selected the Automated Cloud Flow and have as well Selected the trigger as which   "When a new response is submitted” and added the Flow Name which is ”Leave Request Approval Flow”
![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.003.png)

The Leave Request Form works accordingly and being linked in with the form ID
![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.004.png)
They are both connected.
![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.005.png)

Get Response Details is well connected with the Microsoft Forms
![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.006.png)
Create item within SharePoint has linked successfully.
![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.007.png)
List of Columns by View that will be shared within the SharePoint
![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.008.png)
The final flow of the automated cloud flow
![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.009.png)



End Results

https://capeitinitiative.sharepoint.com/sites/AutomatedLeaveRequestSystem/Lists/Leave%20Requests/AllItems.aspx?npsAction=createList

![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.010.png)

![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.011.png)
![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.012.png)![](Aspose.Words.b2bed33e-68cf-4ac2-a88a-bbf6f3da2b19.013.png)

